# NOT 13
Game where you pick an item that doesn't have 13 of it on the screen as fast as possible to get high score!