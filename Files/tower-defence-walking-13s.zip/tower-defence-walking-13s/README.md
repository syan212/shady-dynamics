# Tower Defence: Walking Thirteens
Zombies have recived the number thirteen, and they can now walk.\
Marching toward your castle and aiming for your brains.\
Hope still remain as you pocess the towers of defence, you can survive.\
Place towers and defend your land, upgrade to handle the massive waves of strong 13s.\
Castle is also a tower, as last line of defence but the strongest ranging tower.\
Controls: mouse or touch on screen\
Menu: click on 📋 in header to show menu\
Config: you can enable and disable music and sound, there are two songs available that you can switch between in config.\
Infinity Cash: as a fun mod for having overpowered castle since the only way to max it out is having this much cash, from config you can enable this but it cannot be disabled.\
Win: survive the waves and move to next level getting different map but stronger apponent.\
Game is open ended as long it is enjoyable