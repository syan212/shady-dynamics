# Escape From Planet XIII 
It's finally your chance to escape this hideous planetary system! You are sick of it's lush valleys and dense forests! There is no easy way out though. The only reliable escape waypoint is in the middle of the system, through a warphole. To reach it, you need to win races on each planet to be allowed to jump to the next, one closer to the core and your liberty. You can make things happen faster though: after each race you are given the opportunity of skipping one or two planets. For each planet skipped one random element is added that might affect it's difficulty! You will have to play to see which effects can happen and which ones are troublesome for you and not worth taking or which ones look like a free ticket to a quicker escape.

You have two car options:

* Easy Rider: With it's moderated max speed and gripping tires, it might be best suited for your first escape attempts!

* Tofu Drifter: High speed, low grip, 100% drifting. This is your choice if you want the best adrenaline experience, but you might need to practice to take those corners properly!

It was really fun to make this one! I overcomplicated it for myself making it happen on a sphere surface but in the end I was able to make it work and I think that it gives it a pretty cute look and feel! I hope you enjoy it!