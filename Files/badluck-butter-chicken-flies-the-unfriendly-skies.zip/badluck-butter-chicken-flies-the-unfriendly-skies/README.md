# Badluck Butter Chicken - Episode 1
Badluck Butter Chicken (episode 1) is an uncomplicated casual game where you must avoid the falling thirteens and collect coins.

You can get the magnet to attract coins to you for a amount of time, and the shield which allows you to deflect the thireetns for a short time.

There is also one hidden mechanic that can boost your score faster.

## Controls
* Press Z to move left.
* Press X to move right.
* Controls are fully customizable.
* Pressing Enter or Space will start a new game from the main screen, and return to the main screen from the game over screen.

## Features
* Full HD graphics.
* Three musical scores.
* Persistent options.