# Economy Of Motion
Help Dot reach the goal in under 13 steps. It's measured in keystrokes, you have to be judicious about every movement.

WASD, Arrows, Dpad: Walk/Ladder\
Space, Z, A(gamepad): Jump \
If you complete all 13 levels, you'll be scored by total time and total keystrokes. No storage; remembering scores is up to you. Time spent standing on the goal doesn't count.\
If you get stuck, just dance until you explode.