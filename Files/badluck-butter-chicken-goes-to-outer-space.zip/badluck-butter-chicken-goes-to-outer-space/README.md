# Badluck Butter Chicken Goes To Outer Space.
Badluck butter chicken goes to outer space is an uncomplicated casual game where you must avoid the thirteens and collect coins.

You can get the magnet to attract coins to you for a amount of time, the shield which allows you to deflect the thireetns for a short time, and the clock which slows the thirteens down for a short time.

## Controls
* Press Z to steer left.
* Press X to steer right.
* Controls are fully customizable.
* Pressing Enter or Space will start a new game from the main screen, and return to the main screen from the game over screen.

## Features
* Full HD graphics.
* Three musical scores.
* Persistent options.