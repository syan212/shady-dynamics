# Do Not Make 13
A puzzle game about discovery and learning the rules. Draw a line and see what happens.

On mobile, tap the screen once to enable the music. Best played in landscape mode.